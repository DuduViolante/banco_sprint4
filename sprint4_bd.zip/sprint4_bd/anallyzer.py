from pymongo import MongoClient
import json
from bson.objectid import ObjectId

def conectar_mongodb():
    client = MongoClient('mongodb+srv://duduviolante:Dudu0212@anallyzer.e3fxj.mongodb.net/')
    db = client['Anallyzer']
    return db['documentos']

def inserir_cliente(collection, cliente):
    if 'id_cliente' not in cliente:
        cliente['id_cliente'] = str(ObjectId())
    result = collection.insert_one(cliente)
    print(f"Cliente inserido com sucesso! ID: {result.inserted_id}")

def listar_clientes(collection):
    clientes = list(collection.find())
    if not clientes:
        print("Nenhum cliente encontrado.")
    else:
        for cliente in clientes:
            cliente['_id'] = str(cliente['_id'])  # Convertendo ObjectId para string
            print(json.dumps(cliente, indent=4, default=str))

def atualizar_cliente(collection):
    id_cliente = input("Digite o ID do cliente a ser atualizado: ")
    campo = input("Digite o campo a ser atualizado (nm_cliente, email, etc.): ")
    novo_valor = input(f"Digite o novo valor para {campo}: ")

    result = collection.update_one(
        {'id_cliente': int(id_cliente)},  # Convertendo o ID para int
        {'$set': {campo: novo_valor}}
    )
    if result.modified_count > 0:
        print("Cliente atualizado com sucesso!")
    else:
        print("Nenhum cliente encontrado com esse ID ou dados não modificados.")

def apagar_cliente(collection):
    id_cliente = input("Digite o ID do cliente a ser excluído: ")
    result = collection.delete_one({'id_cliente': int(id_cliente)})  # Convertendo o ID para int
    if result.deleted_count > 0:
        print("Cliente excluído com sucesso!")
    else:
        print("Nenhum cliente encontrado com esse ID.")

def exportar_dados(collection):
    clientes = list(collection.find())
    with open('clientes_exportados.json', 'w') as arquivo:
        json.dump(clientes, arquivo, indent=4, default=str)
    print("Dados exportados com sucesso para 'clientes_exportados.json'.")

def menu():
    collection = conectar_mongodb()
    
    # Lista de clientes baseada nos dados fornecidos
    clientes = [
        {
          "id_cliente": 1,
          "id_campanha": 5,
          "id_genero": 2,
          "id_est_civ": 1,
          "id_escolaridade": 3,
          "nm_cliente": "Maria Silva",
          "email": "maria.silva@example.com",
          "password": "abcd1234",
          "dt_nascimento": "1985-10-15T00:00:00Z",
          "campanha": {
              "id_campanha": 5,
              "id_regiao": 2,
              "id_empresa": 4,
              "data_hora": "2024-10-01T14:30:00Z",
              "clicks_efetivos": 120
          },
          "genero": {
              "id_genero": 2,
              "fl_sexo_biologico": "F"
          },
          "estado_civil": {
              "id_est_civ": 1,
              "ds_estado_civil": "Solteira"
          },
          "escolaridade": {
              "id_escolaridade": 3,
              "ds_escolaridade": "Ensino Superior Completo"
          }
        },
        {
          "id_cliente": 2,
          "id_campanha": 8,
          "id_genero": 1,
          "id_est_civ": 2,
          "id_escolaridade": 4,
          "nm_cliente": "João Pereira",
          "email": "joao.pereira@example.com",
          "password": "efgh5678",
          "dt_nascimento": "1990-05-20T00:00:00Z",
          "campanha": {
              "id_campanha": 8,
              "id_regiao": 5,
              "id_empresa": 2,
              "data_hora": "2024-11-05T09:00:00Z",
              "clicks_efetivos": 250
          },
          "genero": {
              "id_genero": 1,
              "fl_sexo_biologico": "M"
          },
          "estado_civil": {
              "id_est_civ": 2,
              "ds_estado_civil": "Casado"
          },
          "escolaridade": {
              "id_escolaridade": 4,
              "ds_escolaridade": "Ensino Médio Completo"
          }
        },
        {
          "id_cliente": 3,
          "id_campanha": 3,
          "id_genero": 3,
          "id_est_civ": 3,
          "id_escolaridade": 3,
          "nm_cliente": "Ana Costa",
          "email": "ana.costa@example.com",
          "password": "ijkl91011",
          "dt_nascimento": "1992-03-10T00:00:00Z",
          "campanha": {
              "id_campanha": 3,
              "id_regiao": 4,
              "id_empresa": 3,
              "data_hora": "2024-11-10T11:00:00Z",
              "clicks_efetivos": 400
          },
          "genero": {
              "id_genero": 3,
              "fl_sexo_biologico": "I"
          },
          "estado_civil": {
              "id_est_civ": 3,
              "ds_estado_civil": "Divorciado"
          },
          "escolaridade": {
              "id_escolaridade": 3,
              "ds_escolaridade": "Pós-Graduação"
          }
        },
        {
          "id_cliente": 9,
          "id_campanha": 18,
          "id_genero": 2,
          "id_est_civ": 4,
          "id_escolaridade": 7,
          "nm_cliente": "Carlos Eduardo",
          "email": "carlos.eduardo@example.com",
          "password": "qrst1415",
          "dt_nascimento": "1975-07-16T00:00:00Z",
          "campanha": {
              "id_campanha": 18,
              "id_regiao": 12,
              "id_empresa": 3,
              "data_hora": "2024-11-20T10:30:00Z",
              "clicks_efetivos": 275
          },
          "genero": {
              "id_genero": 2,
              "fl_sexo_biologico": "M"
          },
          "estado_civil": {
              "id_est_civ": 4,
              "ds_estado_civil": "Separado"
          },
          "escolaridade": {
              "id_escolaridade": 7,
              "ds_escolaridade": "Ensino Técnico"
          }
        },
        {
          "id_cliente": 14,
          "id_campanha": 25,
          "id_genero": 3,
          "id_est_civ": 5,
          "id_escolaridade": 6,
          "nm_cliente": "Eduarda Oliveira",
          "email": "eduarda.oliveira@example.com",
          "password": "uvwx1617",
          "dt_nascimento": "2000-01-05T00:00:00Z",
          "campanha": {
              "id_campanha": 25,
              "id_regiao": 15,
              "id_empresa": 7,
              "data_hora": "2024-11-25T14:45:00Z",
              "clicks_efetivos": 350
          },
          "genero": {
              "id_genero": 3,
              "fl_sexo_biologico": "F"
          },
          "estado_civil": {
              "id_est_civ": 5,
              "ds_estado_civil": "Solteira"
          },
          "escolaridade": {
              "id_escolaridade": 6,
              "ds_escolaridade": "Ensino Superior Incompleto"
          }
        },
        {
          "id_cliente": 21,
          "id_campanha": 30,
          "id_genero": 1,
          "id_est_civ": 2,
          "id_escolaridade": 8,
          "nm_cliente": "Lucas Ferraz",
          "email": "lucas.ferraz@example.com",
          "password": "yzab1819",
          "dt_nascimento": "1983-09-30T00:00:00Z",
          "campanha": {
              "id_campanha": 30,
              "id_regiao": 9,
              "id_empresa": 5,
              "data_hora": "2024-12-01T09:15:00Z",
              "clicks_efetivos": 220
          },
          "genero": {
              "id_genero": 1,
              "fl_sexo_biologico": "M"
          },
          "estado_civil": {
              "id_est_civ": 2,
              "ds_estado_civil": "Casado"
          },
          "escolaridade": {
              "id_escolaridade": 8,
              "ds_escolaridade": "Ensino Médio Completo"
          }
        },
        {
          "id_cliente": 34,
          "id_campanha": 40,
          "id_genero": 2,
          "id_est_civ": 1,
          "id_escolaridade": 5,
          "nm_cliente": "Fernanda Souza",
          "email": "fernanda.souza@example.com",
          "password": "cdef2021",
          "dt_nascimento": "1995-04-18T00:00:00Z",
          "campanha": {
              "id_campanha": 40,
              "id_regiao": 7,
              "id_empresa": 11,
              "data_hora": "2024-12-05T13:00:00Z",
              "clicks_efetivos": 500
          },
          "genero": {
              "id_genero": 2,
              "fl_sexo_biologico": "F"
          },
          "estado_civil": {
              "id_est_civ": 1,
              "ds_estado_civil": "Solteira"
          },
          "escolaridade": {
              "id_escolaridade": 5,
              "ds_escolaridade": "Ensino Superior Completo"
          }
        },
        {
          "id_cliente": 47,
          "id_campanha": 53,
          "id_genero": 1,
          "id_est_civ": 6,
          "id_escolaridade": 4,
          "nm_cliente": "Rafael Alves",
          "email": "rafael.alves@example.com",
          "password": "ghij2223",
          "dt_nascimento": "1978-11-02T00:00:00Z",
          "campanha": {
              "id_campanha": 53,
              "id_regiao": 14,
              "id_empresa": 9,
              "data_hora": "2024-12-10T16:30:00Z",
              "clicks_efetivos": 430
          },
          "genero": {
              "id_genero": 1,
              "fl_sexo_biologico": "M"
          },
          "estado_civil": {
              "id_est_civ": 6,
              "ds_estado_civil": "Viúvo"
          },
          "escolaridade": {
              "id_escolaridade": 4,
              "ds_escolaridade": "Ensino Médio Incompleto"
          }
        },
        {
          "id_cliente": 52,
          "id_campanha": 67,
          "id_genero": 3,
          "id_est_civ": 3,
          "id_escolaridade": 9,
          "nm_cliente": "Mariana Silva",
          "email": "mariana.silva@example.com",
          "password": "klmn2425",
          "dt_nascimento": "1993-08-12T00:00:00Z",
          "campanha": {
              "id_campanha": 67,
              "id_regiao": 11,
              "id_empresa": 4,
              "data_hora": "2024-12-15T18:45:00Z",
              "clicks_efetivos": 315
          },
          "genero": {
              "id_genero": 3,
              "fl_sexo_biologico": "F"
          },
          "estado_civil": {
              "id_est_civ": 3,
              "ds_estado_civil": "Separada"
          },
          "escolaridade": {
              "id_escolaridade": 9,
              "ds_escolaridade": "Mestrado"
          }
        },
        {
          "id_cliente": 65,
          "id_campanha": 75,
          "id_genero": 2,
          "id_est_civ": 4,
          "id_escolaridade": 11,
          "nm_cliente": "Pedro Costa",
          "email": "pedro.costa@example.com",
          "password": "opqr2627",
          "dt_nascimento": "1985-02-14T00:00:00Z",
          "campanha": {
              "id_campanha": 75,
              "id_regiao": 13,
              "id_empresa": 8,
              "data_hora": "2024-12-20T20:00:00Z",
              "clicks_efetivos": 490
          },
          "genero": {
              "id_genero": 2,
              "fl_sexo_biologico": "M"
          },
          "estado_civil": {
              "id_est_civ": 4,
              "ds_estado_civil": "Divorciado"
          },
          "escolaridade": {
              "id_escolaridade": 11,
              "ds_escolaridade": "Doutorado"
          }
        }
    ]

    while True:
        print("\nEscolha uma operação:")
        print("1. Inserir cliente")
        print("2. Listar clientes")
        print("3. Atualizar cliente")
        print("4. Apagar cliente")
        print("5. Exportar dados")
        print("6. Sair")
        escolha = input("Digite o número da operação desejada: ")

        if escolha == '1':
            # Inserir cliente
            print("\nEscolha um documento para inserir:")
            for i, cliente in enumerate(clientes, start=1):
                print(f"{i}. Cliente: {cliente['nm_cliente']}")
            escolha_cliente = input("Digite o número do cliente para inserir: ")

            if escolha_cliente.isdigit() and 1 <= int(escolha_cliente) <= len(clientes):
                inserir_cliente(collection, clientes[int(escolha_cliente) - 1])
            else:
                print("Escolha inválida.")

        elif escolha == '2':
            listar_clientes(collection)
        elif escolha == '3':
            atualizar_cliente(collection)
        elif escolha == '4':
            apagar_cliente(collection)
        elif escolha == '5':
            exportar_dados(collection)
        elif escolha == '6':
            print("Saindo...")
            break
        else:
            print("Escolha inválida. Tente novamente.")

if __name__ == "__main__":
    menu()